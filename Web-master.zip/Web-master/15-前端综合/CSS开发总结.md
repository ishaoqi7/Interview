
### p标签里的文字溢出怎么办

加一个属性即可：

```css
	word-break: break-all;

```

### inline-block 相关

图片默认是 inline-block 布局，会存在经典的底部 3px 的问题。
