


## 控制台的使用

### 控制台查看源码

控制台的`Sources`标签可以查看源码。按住快捷键「cmd + P」，可以根据文件名查找源码文件。



## 其他

### show user agent shadow DOM

![](http://img.smyhvae.com/20180206_1610.png)


![](http://img.smyhvae.com/20180206_1616.png)

把上图中的红框部分打钩。





